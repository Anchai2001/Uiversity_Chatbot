from weasel.cli.remote_storage import *
