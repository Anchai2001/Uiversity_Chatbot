"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.bg.examples import sentences
>>> docs = nlp.pipe(sentences)
"""

sentences = [
    "Епъл иска да купи английски стартъп за 1 милиард долара."
    "Автономните коли прехвърлят застрахователната отговорност към производителите."
    "Сан Франциско обмисля забрана на роботи доставящи по тротоари. "
    "Лондон е голям град в Обединеното Кралство."
]
